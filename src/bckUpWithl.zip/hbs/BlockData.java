package hbs;

public class BlockData {

	long addr;
	byte[] value;
}
