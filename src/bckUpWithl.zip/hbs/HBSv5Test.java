package hbs;

public class HBSv5Test {

	static long clientBlockSize = 1<<16;
	static long hadoopBlockSize = 1<<19;
	
	private static void write(HBSv5 client, String imageKey){
		for (int i=0; i<4000; i++){
			if  (i%1000==0) System.out.println(i);
			client.writeBlock(imageKey, i*clientBlockSize, HbsUtil2.genDefaultBlockData2(i*clientBlockSize, clientBlockSize));
		}
	}
	
	private static void writeReadTest(HBSv5 client, String imageKey){
		for (int i=0; i<1000; i++){
			client.writeBlock(imageKey, i*clientBlockSize, HbsUtil2.genDefaultBlockData2(i*clientBlockSize, clientBlockSize));
		}
		System.out.println(" initial write done");
		System.out.println(System.currentTimeMillis());
		for (int i=1000; i<3000; i++){
			client.writeBlock(imageKey, i*clientBlockSize, HbsUtil2.genDefaultBlockData2(i*clientBlockSize, clientBlockSize));
			BlockData b = client.readBlock(imageKey, (i-1000)*clientBlockSize).get(0);
		}
	}
	
	public static void main(String args[]){
		HblockConnectionManager hblockConnectionManager = new HblockConnectionManager();
		
		HBSv5 client1 = hblockConnectionManager.createNewBlockStore();
		String imageKey1 = client1.createImage(1<<30, clientBlockSize, hadoopBlockSize );
		System.out.println("imageKey1 " + imageKey1);
		
		HBSv5 client2 =hblockConnectionManager.getBlockStore(imageKey1);

		System.out.println(System.currentTimeMillis());
		
		writeReadTest(client1, imageKey1);
		
		System.out.println(System.currentTimeMillis());
//		write(client1, imageKey1);
//		System.out.println(System.currentTimeMillis());
//		
//		for (int i=0; i<4000; i++){
//			BlockData b = client1.readBlock(imageKey1, i*clientBlockSize).get(0);
//		}
//		System.out.println(System.currentTimeMillis());
//		
//		System.out.println("read 1 done");
		
//		for (int i=0; i<100; i++){
//			BlockData b = client2.readBlock(imageKey1, i*clientBlockSize).get(0);
////			HbsUtil2.printBlockData(b);
//		}
//		System.out.println(System.currentTimeMillis());

//		HBSv5 client2 = hblockConnectionManager.createNewBlockStore();
//		client2.createImage(0, clientBlockSize, hadoopBlockSize );
		
	}
}
