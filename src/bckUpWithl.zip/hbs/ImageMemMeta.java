package hbs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class ImageMemMeta {
	
	public long clientBlockSize ;
	public long hadoopBlockSize ;
	
	public FSDataOutputStream currentAppendStream;
	public short currentFile;
	public ArrayList<FSDataInputStream> readStreams;
	public long maxFileSize  ;
	public short maxFileNumber;
	public String imageKey;
	public String imageUser;
	public long imageSize;
	public MaxSizeHashMap<Long, BlockData> userCache;
	private int USER_CACHE_LIMIT = 1000;
	
	public Map<Long, AddrDataMapValue > blocksDirectory;
	public static HblockConnectionManager hblockConnectionManager;
	
	public void closeAppendStream(){
		if (currentAppendStream == null) return;
		try{
			currentAppendStream.close();			
			currentAppendStream = null;
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public void openAppendStream(){
		if (currentAppendStream !=null) return;
		try{
			Path currPath = new Path(hblockConnectionManager.prefix + imageUser + "/" + imageKey + "/" + currentFile );
			currentAppendStream = hblockConnectionManager.fs.append(currPath);			
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public void reOpenAppendStream(){
		closeAppendStream();
		openAppendStream();

	}
	
	public ImageMemMeta(String imagekey, String imageuser, long maxfilesize, short maxfilenumber, long imagesize, long clientblocksize, long hadoopblocksize,
				HblockConnectionManager imagemanager  ){
		imageKey = imagekey;
		imageUser = imageuser;
		imageSize = imagesize;
		hblockConnectionManager = imagemanager;
		maxFileSize = maxfilesize;
		maxFileNumber = maxfilenumber;
		clientBlockSize = clientblocksize;
		hadoopBlockSize = hadoopblocksize;
		currentFile = 0;
		Path currPath = new Path(hblockConnectionManager.prefix + imageUser + "/" + imageKey + "/" + currentFile );
		readStreams = new ArrayList<FSDataInputStream>(maxFileNumber);
		try {
			currentAppendStream = hblockConnectionManager.fs.create(currPath);
			currentAppendStream.hflush();
			readStreams.add(currentFile, hblockConnectionManager.fs.open(currPath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		blocksDirectory = new HashMap<Long, AddrDataMapValue>();
		userCache = new MaxSizeHashMap(USER_CACHE_LIMIT);
	}
	
	public void SetNextAppendStream() throws IOException{
		this.currentAppendStream.close();
		Path oldPath = new Path(hblockConnectionManager.prefix + imageUser + "/" + imageKey + "/" + currentFile );
		readStreams.add(currentFile, hblockConnectionManager.fs.open(oldPath));
		int i;boolean found = false;
		for( i=0; i< maxFileNumber; i++){
			if(readStreams.get(i) == null ){
				found = true;
				break;
			}
		}
		if(found = true){
			Path p = new Path(hblockConnectionManager.prefix + imageUser + "/" + imageKey + "/" + i );
			currentAppendStream =hblockConnectionManager.fs.create(p); 
			currentFile = (short)i;	
		}
		else{
			//TODO try to commit
			for( i=0; ; i++){
				i = i%maxFileNumber;
				if(readStreams.get(i) == null ){
					found = true;
					break;
				}
			}
		}
	}
	
}
