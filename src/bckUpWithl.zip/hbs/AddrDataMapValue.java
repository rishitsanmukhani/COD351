package hbs;

public class AddrDataMapValue {
	short fileNumber;
	long addrOffset;
	
	public AddrDataMapValue(short a, long b){
		fileNumber = a;
		addrOffset = b;
	}
	
}
