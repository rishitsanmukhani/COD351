package hbs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.ipc.ProtocolSignature;

public class HBSv5 implements BlockProtocolNew{
	
	public HblockConnectionManager hblockConnectionManager;
	
	private ImageMemMeta imageMemMeta;
	private String user = "testuser";
	
	public HBSv5(ImageMemMeta imageMemMeta, HblockConnectionManager hblockConnectionManager) {
		this.hblockConnectionManager = hblockConnectionManager;
		this.imageMemMeta = imageMemMeta;
	}
	
	// follow with createImage
	public HBSv5(HblockConnectionManager hblockConnectionManager) {
		this.hblockConnectionManager = hblockConnectionManager;
	}
	
	@Override
	public ProtocolSignature getProtocolSignature(String arg0, long arg1, int arg2) throws IOException {
		return null;
	}

	@Override
	public long getProtocolVersion(String arg0, long arg1) throws IOException {
		return 5L;
	}

	@Override
	public String createImage(long size, long clientBlockSize, long hadoopBlockSize) {
		imageMemMeta = hblockConnectionManager.createImageMemMeta( user, size, clientBlockSize, hadoopBlockSize);
//		System.out.println("")
		return imageMemMeta.imageKey;
	}

	@Override
	public File getImage(String imageKey) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public boolean writeBlock(String imageKey, long addr, BlockData block) {
		if(addr > imageMemMeta.imageSize){
			System.err.println("addr greater than image size");
			return false;
		}
		if (imageMemMeta.currentAppendStream == null) imageMemMeta.openAppendStream();
		FSDataOutputStream appendStream = imageMemMeta.currentAppendStream;
		long position;
		try {
			position = appendStream.getPos();
			if(position + 8 + imageMemMeta.clientBlockSize > imageMemMeta.maxFileSize){
				imageMemMeta.SetNextAppendStream();
				appendStream = imageMemMeta.currentAppendStream;
				position = appendStream.getPos();	
			}
			imageMemMeta.userCache.put(addr, block);
			appendStream.writeLong(addr);
			appendStream.write(block.value);
			appendStream.hflush();
			imageMemMeta.blocksDirectory.put(addr, new AddrDataMapValue(imageMemMeta.currentFile, position + 8));
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void readBlockToCache(String imageKey, long addr) {
		if (imageMemMeta.userCache.containsKey(addr)){
			return;
		}
		if(addr > imageMemMeta.imageSize){
			System.err.println("addr greater than image size");
			return ;
		}
		AddrDataMapValue location =  imageMemMeta.blocksDirectory.get(addr);
		BlockData def = HbsUtil2.genDefaultBlockData(addr, imageMemMeta.clientBlockSize);
		if(location == null ){
			System.out.println("location is null : ");
			return;
		}
		FSDataInputStream inpStream = imageMemMeta.readStreams.get(location.fileNumber);
		try {
			int written = inpStream.read(location.addrOffset,def.value , 0, (int)imageMemMeta.clientBlockSize );
		} catch (IOException e) {
			e.printStackTrace();
		}
//		System.out.println(" inserting " + addr + " into user Cache");
		imageMemMeta.userCache.put(addr, def);
	}

	
	@Override
	public List<BlockData> readBlock(String imageKey, long addr) {
		if(addr > imageMemMeta.imageSize){
			System.err.println("addr greater than image size");
			return null;
		}
		ArrayList<BlockData> ans = new ArrayList<BlockData>();
		BlockData toRetFromCache = imageMemMeta.userCache.get(addr);
		if (toRetFromCache != null){
//			System.out.println("returing from cache "+ addr);
			ans.add(toRetFromCache);
			return ans;
		}
		AddrDataMapValue location =  imageMemMeta.blocksDirectory.get(addr);
		
		BlockData def = HbsUtil2.genDefaultBlockData(addr, imageMemMeta.clientBlockSize);
		if(location == null ){
			System.out.println("location is null : ");
			ans.add(def);
			return ans;
		}
		FSDataInputStream inpStream = imageMemMeta.readStreams.get(location.fileNumber);
		try {
			if (imageMemMeta.currentFile == location.fileNumber & imageMemMeta.currentAppendStream!=null){
				imageMemMeta.closeAppendStream();
				inpStream.close();
				inpStream = hblockConnectionManager.fs.open(new Path(hblockConnectionManager.prefix + imageMemMeta.imageUser + "/" + imageKey + "/" + location.fileNumber));
				imageMemMeta.readStreams.add(location.fileNumber, inpStream);				
			}
//			System.out.println("inpstream" + inpStream.available() + " " + location.addrOffset + " " + location.fileNumber);
			int written = inpStream.read(location.addrOffset,def.value , 0, (int)imageMemMeta.clientBlockSize );
			for (int i=0; i<8; i++){
				readBlockToCache(imageKey, addr+i*imageMemMeta.clientBlockSize);
			}
//			System.out.println(" written : " + location.addrOffset + " " + location.fileNumber + " " + written);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ans.add(def);
		return ans;
	}

	@Override
	public String takeSnapShot(String imageKey) {
		try {
			Path currPath = new Path(hblockConnectionManager.prefix + imageMemMeta.imageUser + "/" + imageMemMeta.imageKey + "/");
			hblockConnectionManager.hdfsAdmin.allowSnapshot(currPath);
			String newPath = hblockConnectionManager.fs.createSnapshot(currPath).toString();
			return newPath;
			//TODO refine. This is not the imagKey, this is just the location of the snapshot in hdfs. Snapshots are no longer images. They are readonly.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}

	@Override
	public boolean extendImage(String imageKey, long newSize) {
		if(newSize >= imageMemMeta.imageSize){
			imageMemMeta.imageSize = newSize;
			return true;
		}
		return false;
	}

	@Override
	public boolean trimImage(String imageKey, long newSize) {
		//TODO in background job check if the image is actually trimmed.
		if(newSize <= imageMemMeta.imageSize){
			imageMemMeta.imageSize = newSize;
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteImage(String imageKey) {
		try {
			imageMemMeta.currentAppendStream.close();
			for(int i=0; i< imageMemMeta.readStreams.size(); i++){
				imageMemMeta.readStreams.get(i).close();
			}
			Path oldPath = new Path(hblockConnectionManager.prefix + imageMemMeta.imageUser + "/" + imageMemMeta.imageKey + "/");
			hblockConnectionManager.fs.delete(oldPath, false);
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean commit(String imageKey) {
//		imageMemMeta.reOpenAppendStream();
		return true;	
	}

}
