package hbs;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.hdfs.client.HdfsAdmin;

public class HblockConnectionManager {
	
	private Map<String, ImageMemMeta> imagesDirectory;
	public String prefix = "/user/Hblock/v0.5/";
	HbsUtil2 util = new HbsUtil2();
	public HdfsAdmin hdfsAdmin ; 
	public FileSystem fs =  HbsUtil2.getFileSystem();
	public HblockConnectionManager(){
		URI a  = HbsUtil2.getFileSystem().getUri();
		 try {
			hdfsAdmin = new HdfsAdmin(a,HbsUtil2.getConfiguration() );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 imagesDirectory = new HashMap<String, ImageMemMeta>();
	}

	public HBSv5 createNewBlockStore(){
		return new HBSv5(this);
	}
	
	public HBSv5 getBlockStore(String imageKey){
		ImageMemMeta imageMemMeta = imagesDirectory.get(imageKey); 
		return new HBSv5(imageMemMeta,this);
	}
	
	public ImageMemMeta getImageMemMeta(String imageKey){
		return imagesDirectory.get(imageKey);
	}
	
	public ImageMemMeta createImageMemMeta(String user, long imageSize, long clientBlockSize, long hadoopBlockSize){
		String imageKey = util.generateString();
		ImageMemMeta newImageMeta = new ImageMemMeta(imageKey, user, imageSize, (short)6, imageSize, clientBlockSize, hadoopBlockSize, this) ;
		imagesDirectory.put(imageKey, newImageMeta);
		return newImageMeta;
	}
	
}
